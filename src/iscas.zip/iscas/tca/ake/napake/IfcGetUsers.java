package iscas.tca.ake.napake;

import iscas.tca.ake.util.exceptions.CannotFindSuchIDException;

/*
* Copyright 2015 name changchangge123@qq.com
* 
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
* MA 02110-1301, USA.
*
* @Organization: http://tca.iscas.ac.cn/
* @author: Nan Zhou
* @Aknowledge: Tutor Liwu Zhang , Alumnus Yan Zhang, Zhigang Gao
* @Email: changchangge123@qq.com
*/

public interface IfcGetUsers {
	/**
	 * TODO:<return the passwords of the given ids>
	 * @param ids : the querying ids
	 * @return 
	 */
	public String[] getPasswords(String[] ids) throws CannotFindSuchIDException;
	//public String[] getPasswords(String groupID) throws Exception;
	
}
