package iscas.tca.ake.napake;


/**
 * description��<Constants>
 * @author zn
 * @CreateTime 2014-8-17����1:23:56
 */
public class NAPAKEConstants {
	public static final int ProbablePrimeCertainty=0;
	public static final int CountDownLatchStrCnt=2;
}
