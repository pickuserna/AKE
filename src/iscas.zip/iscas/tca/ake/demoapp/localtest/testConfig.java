package iscas.tca.ake.demoapp.localtest;

import iscas.tca.ake.demoapp.mvc.module.Config;

public class testConfig {

	/**
	 * TODO:<>
	 * @param args 
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Config c = Config.newInstance(Config.ConfigPath);
		System.out.println(c.getBulletinDir());
	}

}
