package iscas.tca.ake.demoapp.localtest;

import iscas.tca.ake.demoapp.mvc.controler.ClientControlor;
import iscas.tca.ake.demoapp.mvc.module.tools.SendAndRecv;
import iscas.tca.ake.message.IfcMessage;
import iscas.tca.ake.message.nap.EnumNAPMsgType;
import iscas.tca.ake.message.nap.NAPMessage;

import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class TestDisturbance implements Runnable{

	/**
	 * TODO:<>
	 * @param args 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TestDisturbance().run();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			missedMsg();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//seding missed Message to the server 
	public void missedMsg()throws Exception{
		
		NAPMessage.GroupIDData gid = NAPMessage.GroupIDData.getGroupIDData("group_U");
		
		System.out.println("testMessage");
		
        IfcMessage m1 = new NAPMessage(gid, EnumNAPMsgType.GroupID);
        Socket s = new Socket("localhost", 8007);
        SendAndRecv.sendMsg(m1, s);
        SendAndRecv.recvMsg(s);
	}
	
	public void wrongMsg()throws Exception{
		
	}
}
