package iscas.tca.ake.demoapp.localtest;

import java.net.InetSocketAddress;
import java.net.SocketAddress;

import iscas.tca.ake.demoapp.mvc.module.Response;
import iscas.tca.ake.demoapp.mvc.module.bulletin.ClientBulletin;
import iscas.tca.ake.demoapp.mvc.view.observer.IfcObserver;
import iscas.tca.ake.napake.calculate.NAPAKECalculate;

/*�ļ�����TestBulletin.java
 *������<����>
 *�޸��ˣ�<zn>
 *�޸�ʱ�䣺YYYY��MM-DD
 *�޸ĵ���:
 *�޸����ݣ�<�޸�����>
 *����ʱ�䣺����3:18:25
 */
class ObsBulletin implements IfcObserver{

	@Override
	public void update(Response result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setStatus(String status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateExecution(Response response) {
		// TODO Auto-generated method stub
		
	}
	
}
public class TestBulletin implements Runnable{

	/**
	 * TODO:<>
	 * @param args 
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
	
		ScheduleTask st = new ScheduleTask();
//		st.executeSchedule(new TestMessage(), 1000L, 1000);
		st.executeSchedule(TestBulletin.class, 1000L, 5,new Response(new ObsBulletin()));
		System.out.println("Test Message over!!!");
	}
	public void run(){
		SocketAddress sa = new InetSocketAddress("localhost", 7070);
		ClientBulletin cb = new ClientBulletin("group_U", sa, "user", "user1234", new NAPAKECalculate());
		cb.setProType("NAP");
		cb.run();
	}
}
