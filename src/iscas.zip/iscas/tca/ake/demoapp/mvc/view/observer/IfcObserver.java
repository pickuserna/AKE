package iscas.tca.ake.demoapp.mvc.view.observer;

import iscas.tca.ake.demoapp.mvc.module.Response;


/**
 * @author zn
 * @CreateTime 2014-10-9����10:58:27
 */
public interface IfcObserver extends IfcExecutionObserver{
	public void update(Response result);
	public void setStatus(String status);
	public void updateExecution(Response response);
}
