package iscas.tca.ake.demoapp.mvc.view.observer;

import iscas.tca.ake.demoapp.mvc.module.Response;

/**
 * @author zn
 * @CreateTime 2014-10-13����8:50:47
 */
public interface IfcExecutionObserver {
	void updateExecution(Response response);
}
