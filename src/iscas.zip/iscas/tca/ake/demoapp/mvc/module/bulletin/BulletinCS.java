package iscas.tca.ake.demoapp.mvc.module.bulletin;

public class BulletinCS {

}
