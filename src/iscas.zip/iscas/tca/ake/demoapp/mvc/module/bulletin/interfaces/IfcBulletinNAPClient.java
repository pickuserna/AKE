package iscas.tca.ake.demoapp.mvc.module.bulletin.interfaces;

public interface IfcBulletinNAPClient {
	//get the index of the id in the group
	int index(String id);
	//get the connected Pseudonyms of the group
	String getConnectedPseus();
	String getMsgType();
	
}
