package iscas.tca.ake.demoapp.mvc.module.interf;

/**
 * ������<>
 * @author zn
 * @CreateTime 2014-10-16����10:07:30
 */
public interface IfcSettorForConfig {
	void setConfigArgs(IfcKVTupple settings);
}
