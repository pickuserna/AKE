package iscas.tca.ake.demoapp.mvc.module.interf;

/**
 * ������<>
 * @author zn
 * @CreateTime 2014-10-16����10:08:47
 */
public interface IfcKVTupple {
	public void setArg(String argName, Object argValue);
	public void getArg(String argName);
}
