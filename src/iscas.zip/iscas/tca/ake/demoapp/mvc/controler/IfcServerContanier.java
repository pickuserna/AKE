package iscas.tca.ake.demoapp.mvc.controler;

import iscas.tca.ake.demoapp.mvc.module.Config;

/**
 * @author zn
 * @CreateTime 2014-10-16����11:26:22
 */
public interface IfcServerContanier{
	public void init(Config conifg);
	public void service()throws Exception;
	public void close();
}
