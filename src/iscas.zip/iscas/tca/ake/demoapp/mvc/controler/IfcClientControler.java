package iscas.tca.ake.demoapp.mvc.controler;

import iscas.tca.ake.demoapp.mvc.module.MyClient;
import iscas.tca.ake.demoapp.mvc.view.observer.IfcObserver;

import java.util.Map;

public interface IfcClientControler {
	void setArgs(IfcObserver obs, Map<String, Object> frameArgs);
	void runIt();
	byte[] getSessionKey();
}
