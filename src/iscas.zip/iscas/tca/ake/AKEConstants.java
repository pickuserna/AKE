package iscas.tca.ake;

/**
 * @author zn
 * @CreateTime 2014-11-18����9:58:23
 */
public class AKEConstants {
	public static final String CT_ProType_SKI = "VEAP";
	public static final String CT_ProType_NAPYZ = "NAP";
}
