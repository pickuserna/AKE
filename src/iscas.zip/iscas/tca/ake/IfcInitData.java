package iscas.tca.ake;

/**
 * @description��<interface of the initial data for the protocol>
 * ��<IfcInitData>
 * @author zn
 * @CreateTime 2014-8-16����10:56:42
 */
public interface IfcInitData {

}
