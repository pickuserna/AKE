package iscas.tca.ake.veap;


/**
 * @TODO get the users of the groupID, implemented by the user of the ServerProtocol
 * @author zn
 * @CreateTime 2014-9-12����4:07:33
 */
public interface IfcGetUsers {
	public User[] getUsers(String groupID);
}
