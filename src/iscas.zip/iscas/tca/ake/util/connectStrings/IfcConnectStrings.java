package iscas.tca.ake.util.connectStrings;

/**
 * ������<>
 * @author zn
 * @CreateTime 2014-9-1����10:14:06
 */
public interface IfcConnectStrings {

	/**
	 * @param ss get the connnected string
	 * @return 
	 */
	public StringBuilder getConnectedString(String[] ss);

}
