package iscas.tca.ake.util.exceptions;

/**
 * @author zn
 * @CreateTime 2014-8-22����9:25:48
 */
public class CannotFindSuchIDException extends Exception{

}
