package iscas.tca.ake.util.exceptions;

/**
// * className��<NotPrimeException>
 * @author zn
 * @CreateTime 2014-8-18����8:34:59
 */
public class InitializationException extends Exception{

}
