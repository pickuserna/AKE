package iscas.tca.ake.util.hashs;

/**
 * @author zn
 * @version 2014-7-31����1:37:42
 */
public interface IfcHash {
	byte[] process(String s);
	//String bytesToString();
}



